package com.cg.employee.dao;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.employee.bean.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao{
	@Autowired
	MongoTemplate repository;

	@Override
	public Employee insertEmployee(Employee employee) {
		// TODO Auto-generated method stub
		repository.save(employee);
		return employee;
	}

	@Override
	public List<Employee> viewEmployee() {
		// TODO Auto-generated method stub
		
		return	repository.findAll(Employee.class);
		 
	}

	@Override
	public Employee deleteEmployee(String empId) {
		Query query=new Query();
		query.addCriteria(Criteria.where("empId").is(empId));
		Employee employee=repository.findOne(query, Employee.class);
		repository.remove(employee);
		return employee;

	}

	@Override
	public Employee updateEmployee(String empId,Employee employee) {
		// TODO Auto-generated method stub
		Query query=new Query();
		query.addCriteria(Criteria.where("empId").is(empId));
		Employee employee1=repository.findOne(query, Employee.class);
		employee.setempId(empId);
		repository.save(employee);
		return employee;
	}

	@Override
	public String deleteAllEmployee() {
		// TODO Auto-generated method stub
		
		return "Records deleted";
	}

	@Override
	public Employee viewbyIDEmployee(String empId) {
		Query query=new Query();
		query.addCriteria(Criteria.where("empId").is(empId));
		return  repository.findOne(query, Employee.class);
	}

}
