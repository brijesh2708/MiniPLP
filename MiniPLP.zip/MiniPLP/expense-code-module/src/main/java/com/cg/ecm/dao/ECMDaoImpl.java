package com.cg.ecm.dao;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.ecm.entity.ExpenseDetails;
import com.cg.ecm.exception.ECMException;
@Repository
public class ECMDaoImpl implements EMCDao{
@Autowired
	MongoTemplate mongotemplate;
	@Override
	public ExpenseDetails addDetails(ExpenseDetails expdetails) throws ECMException {
		expdetails.setExpenseCode(autogenerate());
		if(expdetails!=null){
		mongotemplate.save(expdetails);
		}else{
			throw new ECMException("ExpenseCode already exists");
		}
		return expdetails;
	}
	private int autogenerate() {
		Random random=new Random();
		int n=10000+random.nextInt(90000);
		return n;
	}
	@Override
	public List<ExpenseDetails> getAllDetails() throws ECMException {
		List<ExpenseDetails> list=mongotemplate.findAll(ExpenseDetails.class);
		/*try{*/
			
		if(!list.isEmpty()){
			return list;
		}else{
			throw  new ECMException("NO DATA TO DISPLAY!!");
		}	
		/*}
	catch (ECMException e) {
			System.err.println(e.getMessage());
		}*/
		
	}
	@Override
	public ExpenseDetails getByCode(int expenseCode) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(expenseCode));
		ExpenseDetails details=mongotemplate.findOne(query, ExpenseDetails.class);
		return details;
	}
	@Override
	public String DeleteByCode(int expenseCode) {
		ExpenseDetails detail=getByCode(expenseCode);
		if(detail!=null){
			mongotemplate.remove(detail);
		}
		return "Deleted successfully !";
		
	}
	@Override
	public ExpenseDetails updateDetails(ExpenseDetails expdetails,int expenseCode) throws ECMException {
		ExpenseDetails detail=getByCode(expenseCode);
		expdetails.setExpenseCode(expenseCode);
		System.out.println(detail);
		if(detail!=null)
		{
			mongotemplate.save(expdetails);
		}
		
		else
		{
			throw new ECMException("Nothing to modify");
		}
		return expdetails;
	}

}
