package com.cg.projectcodemodule.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.projectcodemodule.bean.ProjectBean;
import com.cg.projectcodemodule.exception.UserNotFoundException;

@Repository
public class ProjectDaoImpl implements IProjectDao{

	@Autowired
	MongoTemplate mongo;

	@Override
	public ProjectBean insertProjectDetails(ProjectBean projectBean) {
		long startDateSecs=projectBean.getStartDate().getTime();
		long endDateSecs=projectBean.getEndDate().getTime();
		long diff=startDateSecs-endDateSecs;
		if(diff>=0){
			throw new UserNotFoundException("End date should be greater than start date");
		}

		mongo.save(projectBean);
		return projectBean;
	}

	@Override
	public List<ProjectBean> viewProjectDetails() {
		// TODO Auto-generated method stub
		return mongo.findAll(ProjectBean.class);
	}

	@Override
	public ProjectBean viewProjectDetailsByCode(String projectCode) {
		// TODO Auto-generated method stub
		Query query=new Query();
		query.addCriteria(Criteria.where("projectCode").is(projectCode));
		return mongo.findOne(query, ProjectBean.class);
	}

	@Override
	public ProjectBean deleteProjectDetailsByCode(String projectCode) {
		// TODO Auto-generated method stub
		Query query=new Query();
		query.addCriteria(Criteria.where("projectCode").is(projectCode));
		ProjectBean projectBean = mongo.findOne(query, ProjectBean.class);
		mongo.remove(projectBean);
		return projectBean;
	}

	@Override
	public ProjectBean updateProjectDetails(String projectCode,ProjectBean projectBean) {
		Query query=new Query();
		query.addCriteria(Criteria.where("projectCode").is(projectCode));
		mongo.findOne(query, ProjectBean.class);
		projectBean.setProjectCode(projectCode);
		mongo.save(projectBean);
		return projectBean;
	}

}
